def read_and_alert(request): return 'Bootstrap OK'
